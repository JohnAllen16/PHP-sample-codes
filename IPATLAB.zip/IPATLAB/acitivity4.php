<?php
$connect = mysql_connect("localhost","root","","","menu")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=20, initial-scale=1.0">
    <title>POS</title>
</head>
<style>
   body {
    background-color: #fafa6e;
}
</style>
<body>
    <center>
<h2>
    BURGERAN NI MARITES
</h2>
 <div class="row"> 
<p> MENU: </p>

<br>
<?php
$query="SELECT * FROM products";
$result= mysql_query($connect,$query);

while ($row=mysqli_fetch_array($result)){?>
<div class="col-md-4"></div>
<form action="acitivity4.php?id=<?=$row['id']?>" method="get">
    <img src="img/<?row['img']?>" style='height:150px;'>
    <h2><?=$row['name'];?></h2>
    <h2><?=$row['price'];?></h2>
 
</form>
</div>}
 <br>


</div>
</center>
</body>
</html>