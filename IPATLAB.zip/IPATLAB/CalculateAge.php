<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
 
 
<style type="text/css"> 
gin-top: 0;
      font-weight: 500;
      }
      form {
      position: relative;
      width: 80%;
      border-radius: 30px;
      background: #fff;
      box-shadow: -30px 30px 0px rgba(0, 0, 0, 0.3);
      }
       
      .form-inner {
      padding: 40px;
      }
      .form-inner input,
      .form-inner textarea {
      display: block;
      width: 100%;
      padding: 15px;
      margin-bottom: 10px;
      border: none;
      border-radius: 20px;
      
      }
       
      button {
      width: 100%;
      padding: 10px;
      margin-top: 20px;
      border-radius: 20px;
      border: none;
      border-bottom: 4px solid #3e4f24;
      background: #4ae91a; 
      font-size: 16px;
      font-weight: 400;
      color: #fff;
      }
      
      @media (min-width: 568px) {
      form {
      width: 60%;
      }
      }
      form option {
 
 color: #292e28;
 font-size:10;
}
.day{
    font-size: 20px;
}
.calculate {
 width: 15%;
 background:#4ae91a;
 color: white;
 font-size: 18pt;
 border-radius: 15px;
 cursor:pointer;
 width: 100%;
   
    
      }
      
 
.calculate:hover{
    background-color: darkgreen;
    margin-bottom: 11px;
}
 
    </style>
  </head>
  <body>
 
 
<form action="CalculateAge.php" method="post" class="drop" >

      <div class="form-left-decoration"></div>
      <div class="form-right-decoration"></div>
      <div class="circle"></div>
      <div class="form-inner">
        <fieldset><h1>ENTER BIRTH DATE</h1>
        <center>
       <select name="day" select class="day"> 
 <option value="01">01</option>
 <option value="02">02</option>
 <option value="03">03</option>
 <option value="04">04</option>
 <option value="05">05</option>
 <option value="06">06</option>
 <option value="07">07</option>
 <option value="08">08</option>
 <option value="09">09</option>
 <option value="10">10</option>
 <option value="11">11</option>
 <option value="12">12</option>
 <option value="13">13</option>
 <option value="14">14</option>
 <option value="15">15</option>
 <option value="16">16</option>
 <option value="17">17</option>
 <option value="18">18</option>
 <option value="19">19</option>
 <option value="20">20</option>
 <option value="21">21</option>
 <option value="22" selected="selected">22</option>
 <option value="23">23</option>
 <option value="24">24</option>
 <option value="25">25</option>
 <option value="26">26</option>
 <option value="27">27</option>
 <option value="28">28</option>
 <option value="29">29</option>
 <option value="30">30</option>
 <option value="31">31</option>
 
</select>
       
        <select name="month" select class="day">
 <option value="1">January</option>
 <option value="2">Febuary</option>
 <option value="3">March</option>
 <option value="4">April</option>
 <option value="5">May</option>
 <option value="6">June</option>
 <option value="7">July</option>
 <option value="8">August</option>
 <option value="9">September</option>
 <option value="10">October</option>
 <option value="11">November</option>
 <option value="12" selected="selected">December</option>
 </select>

        
         <select name="year" select class="day">
 <option value="2014">2014</option>
 <option value="2013">2013</option>
 <option value="2012">2012</option>
 <option value="2011">2011</option>
 <option value="2010">2010</option>
 <option value="2009">2009</option>
 <option value="2008">2008</option>
 <option value="2007">2007</option>
 <option value="2006">2006</option>
 <option value="2005">2005</option>
 <option value="2004">2004</option>
 <option value="2003">2003</option>
 <option value="2002">2002</option>
 <option value="2001">2001</option>
 <option value="2000" selected="selected">2000</option>
 <option value="1999">1999</option>
 <option value="1998">1998</option>
 <option value="1997">1997</option>
 <option value="1996">1996</option>
 <option value="1995">1995</option>
 <option value="1994">1994</option>
 <option value="1993">1993</option>
 <option value="1992">1992</option>
 <option value="1991">1991</option>
 <option value="1990">1990</option>
 <option value="1989">1989</option>
 <option value="1988">1988</option>
 <option value="1987">1987</option>
 <option value="1986">1986</option>
 <option value="1985">1985</option>
 <option value="1984">1984</option>
 <option value="1983">1983</option>
 <option value="1982">1982</option>
 <option value="1981">1981</option>
 <option value="1980">1980</option>
 <option value="1979">1979</option>
 <option value="1978">1978</option>
 <option value="1977">1977</option>
 <option value="1976">1976</option>
 <option value="1975">1975</option>
 <option value="1974">1974</option>
 <option value="1973">1973</option>
 <option value="1972">1972</option>
 <option value="1971">1971</option>
 <option value="1970">1970</option>
 <option value="1969">1969</option>
 <option value="1968">1968</option>
 <option value="1967">1967</option>
 <option value="1966">1966</option>
 <option value="1965">1965</option>
 <option value="1964">1964</option>
 <option value="1963">1963</option>
 <option value="1962">1962</option>
 <option value="1961">1961</option>
 <option value="1960">1960</option>
 <option value="1959">1959</option>
 <option value="1958">1958</option>
 <option value="1957">1957</option>
 <option value="1956">1956</option>
 <option value="1955">1955</option>
 <option value="1954">1954</option>
 <option value="1953">1953</option>
 <option value="1952">1952</option>
 <option value="1951">1951</option>
 <option value="1950">1950</option>
 <option value="1949">1949</option>
 <option value="1948">1948</option>
 <option value="1947">1947</option>
 <option value="1946">1946</option>
 <option value="1945">1945</option>
 <option value="1944">1944</option>
 <option value="1943">1943</option>
 <option value="1942">1942</option>
 <option value="1941">1941</option>
 <option value="1940">1940</option>
 <option value="1939">1939</option>
 <option value="1938">1938</option>
 <option value="1937">1937</option>
 <option value="1936">1936</option>
 <option value="1935">1935</option>
 <option value="1934">1934</option>
 <option value="1933">1933</option>
 <option value="1932">1932</option>
 <option value="1931">1931</option>
 <option value="1930">1930</option>
 </select>
 <br> <br>
 </center>       
   <button> <input name="submit" type="submit" value="KNOW THE AGE" class="calculate" />  </button>
     <button> <input name="horoscope" type="submit" value="KNOW THE HOROSCOPE" class="calculate" />  </button> 
     

    
      <br>
      <br>
      <center>
     <?php
if(isset($_POST['submit']))
{

$d=$_POST['day'];
$m=$_POST['month'];
$y=$_POST['year'];
 
$dob=$d.'-'.$m.'-'.$y;
 
$bday=new DateTime($dob);
 
$t=date('d-m-Y');
 
$age=$bday->diff(new DateTime);
 echo '<h1>Your Zodiac is : </h1> ';
if($m==1){
        if ($d<21)
            echo "<p> You're Capricorn!</p>";
        else
            echo "<p> You're Aquarius!</p>";    
    }
    else if($m==2){
        if ($d<19)
            echo "<p> You're Aquarius!</p>";
        else
            echo "<p> You're Pisces!</p>";    
    }
    else if($m==3){
        if ($d<21)
            echo "<p> You're Pisces!</p>";
        else
            echo "<p> You're Aries!</p>";    
    }
    else if($m==4){
        if ($d<20)
            echo "<p> You're Aries!</p>";
        else
            echo "<p> You're Taurus!</p>";    
    }
    else if($m==5){
        if ($d<21)
            echo "<p> You're Taurus!</p>";
        else
            echo "<p> You're Gemini!</p>";    
    }
    else if($m==6){
        if ($d<21)
            echo "<p> You're Gemini!</p>";
        else
            echo "<p> You're Cancer!</p>";    
    }
    else if($m==7){
        if ($d<23)
            echo "<p> You're Cancer!</p>";
        else
            echo "<p> You're Leo!</p>";    
    }
    else if($m==8){
        if ($d<23)
            echo "<p> You're Leo!</p>";
        else
            echo "<p> You're Virgo!</p>";    
    }
    else if($m==9){
        if ($d<23)
            echo "<p> You're Virgo!</p>";
        else
            echo "<p> You're Libra!</p>";    
    }
    else if($m==10){
        if ($d<23)
            echo "<p> You're Libra!</p>";
        else
            echo "<p> You're Scorpio!</p>";    
    }
    else if($m==11){
        if ($d<22)
            echo "<p> You're Scorpio!</p>";
        else
            echo "<p> You're Sagittarius!</p>";    
    }
    else if($m==12){
        if ($d<22)
            echo "<p> You're Sagittarius!</p>";
        else
            echo "<p> You're Capricorn!</p>";    
    }  
    echo '<br />';
 echo '<h2>';
echo '<h1>Your Birth date: </h1>';
echo $dob;
echo '<br>';
echo '<br>';
echo '<h1>Your Age : </h1> ';
echo $age->y;
echo ' Years ';

 
echo '</h2>';
}
 

 
 


 
  if(isset($_POST['horoscope']))
{

$d=$_POST['day'];
$m=$_POST['month'];

if($m==1){
        if ($d<21)
            echo "<p> You're Capricorn!</p><p> The year 2022 will be both promising as well as messy for Capricorn individuals. You have to double your efforts to succeed in the job as well as monetary situations. Hard work and tension will impact your health, and you will also vitiate the family atmosphere.Children will have a tough time during the year. If they are of marriageable age, they will tie the knot. The year is favorable for students to pursue higher education. Do not be deterred by tough situations, and always think of alternatives.</p>";
        else
            echo "<p> You're Aquarius!</p><p> Saturn and Uranus will impact Aquarius zodiac sign in opposite ways. You have to be guided by the advice of family and friends on how to get over challenges during the year 2022. You will do well on the job front, but income will be balanced by expenditure.The last half of the year will be promising for love relationships. Success in your projects is guaranteed in the previous quarter of the year. You have to relax enough to get over the anxieties and worries of your daily life. Lean on others to achieve your goals.</p>";    
    }
    else if($m==2){
        if ($d<19)
            echo "<p> You're Aquarius!</p><p> Saturn and Uranus will impact Aquarius zodiac sign in opposite ways. You have to be guided by the advice of family and friends on how to get over challenges during the year 2022. You will do well on the job front, but income will be balanced by expenditure.The last half of the year will be promising for love relationships. Success in your projects is guaranteed in the previous quarter of the year. You have to relax enough to get over the anxieties and worries of your daily life. Lean on others to achieve your goals.</p>";
        else
            echo "<p> You're Pisces!</p><p> Pisces people should be prepared to face the vagaries of life during the year 2022. You have to handle these situations with an optimistic outlook. Be persistent to achieve your objectives in life. Finances will be tricky with mounting expenses.Family life will be full of tension as you will not be able to devote enough attention. The beginning and end of the year will bring good results in ventures because of Jupiter. Health will be full of vitality despite the various challenges. Follow your instincts to succeed this year.</p>";    
    }
    else if($m==3){
        if ($d<21)
            echo "<p> You're Pisces!</p><p> Pisces people should be prepared to face the vagaries of life during the year 2022. You have to handle these situations with an optimistic outlook. Be persistent to achieve your objectives in life. Finances will be tricky with mounting expenses.Family life will be full of tension as you will not be able to devote enough attention. The beginning and end of the year will bring good results in ventures because of Jupiter. Health will be full of vitality despite the various challenges. Follow your instincts to succeed this year.</p>";
        else
            echo "<p> You're Aries!</p><p> The year 2022 for Aries people will be about collaborations and affiliations. Single people will get into love partnerships. Joint business ventures will succeed. There will be fresh ideas, and you will be busy with the execution of new investments. Married life will be harmonious and will see an accumulation of wealth. There will be more romance and sensuality.You will be careless about your fitness and diet routines. It is essential to relax and come out with a new hobby or exercise. If you want to succeed this year, do not be aggressive. Listen to others and take them along.</p>";    
    }
    else if($m==4){
        if ($d<20)
            echo "<p> You're Aries!</p><p> The year 2022 for Aries people will be about collaborations and affiliations. Single people will get into love partnerships. Joint business ventures will succeed. There will be fresh ideas, and you will be busy with the execution of new investments. Married life will be harmonious and will see an accumulation of wealth. There will be more romance and sensuality.You will be careless about your fitness and diet routines. It is essential to relax and come out with a new hobby or exercise. If you want to succeed this year, do not be aggressive. Listen to others and take them along.</p>";
        else
            echo "<p> You're Taurus!</p><p> The year 2022 promises to be an incredible year for Taurus professionals. They can expect promotions to higher levels along with financial benefits. Business ventures which were dormant will come to life, and you will succeed. You will try to accommodate the views of others. Venus will stimulate your romances this year. There is scope for pregnancy.Jupiter and Mars will make relations peaceful and harmonious. Your social contacts will encourage you to complete projects, and Jupiter will help you achieve success in ventures. Mars will help you to maintain health, and you will be busy with a new hobby.</p>";    
    }
    else if($m==5){
        if ($d<21)
            echo "<p> You're Taurus!</p><p> The year 2022 promises to be an incredible year for Taurus professionals. They can expect promotions to higher levels along with financial benefits. Business ventures which were dormant will come to life, and you will succeed. You will try to accommodate the views of others. Venus will stimulate your romances this year. There is scope for pregnancy.Jupiter and Mars will make relations peaceful and harmonious. Your social contacts will encourage you to complete projects, and Jupiter will help you achieve success in ventures. Mars will help you to maintain health, and you will be busy with a new hobby.</p>";
        else
            echo "<p> You're Gemini!</p><p> Planet Venus will help the Gemini star sign to shine in artistic projects this year. It would help if you went by your moods, and inspiration should be the guiding factor. Saturn will help to plan your life and strive to attain excellence. The beginning of the year will be turbulent for relationships. Venus will help you to regain romance during the latter half of the year.You will succeed in business projects during the second quarter of the year with the help of Mars. It is essential to focus on a fitness and relaxation program you like to maintain your wellbeing. Try to do things that are possible during the year instead of aiming too high.</p>";    
    }
    else if($m==6){
        if ($d<21)
            echo "<p> You're Gemini!</p><p> Planet Venus will help the Gemini star sign to shine in artistic projects this year. It would help if you went by your moods, and inspiration should be the guiding factor. Saturn will help to plan your life and strive to attain excellence. The beginning of the year will be turbulent for relationships. Venus will help you to regain romance during the latter half of the year.You will succeed in business projects during the second quarter of the year with the help of Mars. It is essential to focus on a fitness and relaxation program you like to maintain your wellbeing. Try to do things that are possible during the year instead of aiming too high.</p>";
        else
            echo "<p> You're Cancer!</p><p> Cancer people tend to put others before themselves and go out of the way to help others. To avoid misuse by others, you should educate others to help themselves during the year 2022. You will be able to accomplish projects during the first and last quarter of the year with the help of Jupiter.Love and relationships will bloom after the first quarter of 2022 with the help of Venus and Mars. Jupiter will help you to form new contacts this year and use them to succeed in your ventures. Particularly, the last quarter of the year will be highly encouraging.!</p>";    
    }
    else if($m==7){
        if ($d<23)
            echo "<p> You're Cancer!</p><p> Cancer people tend to put others before themselves and go out of the way to help others. To avoid misuse by others, you should educate others to help themselves during the year 2022. You will be able to accomplish projects during the first and last quarter of the year with the help of Jupiter.Love and relationships will bloom after the first quarter of 2022 with the help of Venus and Mars. Jupiter will help you to form new contacts this year and use them to succeed in your ventures. Particularly, the last quarter of the year will be highly encouraging.!</p>";
        else
            echo "<p> You're Leo!</p><p> Leo professionals will progress in their careers during the beginning of the year as Jupiter is positive. Finances are excellent with a good flow of money. Saturn may help you in getting unexpected wealth. People in confirmed relationships will get married, and the family environment will be harmonious.Health prospects are tentative during the latter half of 2022. Children will progress slowly. They will succeed in competitive examinations. Travels, including foreign trips, are likely, and this will help to advance in your career. You will achieve in life through diplomacy and elegance.</p>";    
    }
    else if($m==8){
        if ($d<23)
            echo "<p> You're Leo!</p><p> Leo professionals will progress in their careers during the beginning of the year as Jupiter is positive. Finances are excellent with a good flow of money. Saturn may help you in getting unexpected wealth. People in confirmed relationships will get married, and the family environment will be harmonious.Health prospects are tentative during the latter half of 2022. Children will progress slowly. They will succeed in competitive examinations. Travels, including foreign trips, are likely, and this will help to advance in your career. You will achieve in life through diplomacy and elegance.</p>";
        else
            echo "<p> You're Virgo!</p><p> Virgo zodiac will succeed in their jobs and financial activities due to their hard work and inspiration. Jupiter will help to know your necessities. You will be able to prosper financially with the help of family and friends and the positive aspects of Jupiter.Saturn and Jupiter together will help to maintain peace and harmony in the family atmosphere. Mars will help you to accomplish projects, and you have to stick to the requirements. Relaxation and sports activities can achieve emotional health. Marriages of children are on the cards during the year 2022.</p>";    
    }
    else if($m==9){
        if ($d<23)
            echo "<p> You're Virgo!</p><p> Virgo zodiac will succeed in their jobs and financial activities due to their hard work and inspiration. Jupiter will help to know your necessities. You will be able to prosper financially with the help of family and friends and the positive aspects of Jupiter.Saturn and Jupiter together will help to maintain peace and harmony in the family atmosphere. Mars will help you to accomplish projects, and you have to stick to the requirements. Relaxation and sports activities can achieve emotional health. Marriages of children are on the cards during the year 2022.</p>";
        else
            echo "<p> You're Libra!</p><p> Jupiter and Saturn will present Libra individuals with prospects of managing their lives as per their choice and in a superior manner during the year 2022. Business partnerships might have problems, and professionals will have a reasonable period. Income too will increase along with expenditure.Venus and Mars are favorable for love and romance. Single persons will get into instant relationships. The family atmosphere will face a few conflicts. You should avoid taking unnecessary risks in ventures, and it will lead to success. You can tackle stressful situations with exercise and relaxation.</p>";    
    }
    else if($m==10){
        if ($d<23)
            echo "<p> You're Libra!</p><p> Jupiter and Saturn will present Libra individuals with prospects of managing their lives as per their choice and in a superior manner during the year 2022. Business partnerships might have problems, and professionals will have a reasonable period. Income too will increase along with expenditure.Venus and Mars are favorable for love and romance. Single persons will get into instant relationships. The family atmosphere will face a few conflicts. You should avoid taking unnecessary risks in ventures, and it will lead to success. You can tackle stressful situations with exercise and relaxation.</p>";
        else
            echo "<p> You're Scorpio!</p><p> The year 2022 presents plenty of shockers for Scorpio people. Professionals will excel in their jobs. Financial rewards will be excellent, while expenses are meager. Social life will be fabulous. Jupiter will shower you with more luck while Saturn tends to regulate it.Love life will be delightful in the last quarter of the year. In all ventures, you have to listen to others and go by their ideas. Health will be fluctuating, and during taxing, times relax with meditation. Students have opportunities for education overseas.</p>";    
    }
    else if($m==11){
        if ($d<22)
            echo "<p> You're Scorpio!</p><p> The year 2022 presents plenty of shockers for Scorpio people. Professionals will excel in their jobs. Financial rewards will be excellent, while expenses are meager. Social life will be fabulous. Jupiter will shower you with more luck while Saturn tends to regulate it.Love life will be delightful in the last quarter of the year. In all ventures, you have to listen to others and go by their ideas. Health will be fluctuating, and during taxing, times relax with meditation. Students have opportunities for education overseas.</p>";
        else
            echo "<p> You're Sagittarius!</p><p> Jupiter and Saturn will give different indications for Sagittarius personality during the year 2022. You can accomplish objectives by being pragmatic and prudent. On the financial front, you have to devise a plan for fiscal prudence if you have to remain afloat.The family atmosphere will be harmonious during the second half of the year. Projects will take off during May and October due to the influence of Jupiter. You have to be realistic in your expectations. Health can be maintained by exercise and recreation.</p>";    
    }
    else if($m==12){
        if ($d<22)
            echo "<p> You're Sagittarius!</p><p> Jupiter and Saturn will give different indications for Sagittarius personality during the year 2022. You can accomplish objectives by being pragmatic and prudent. On the financial front, you have to devise a plan for fiscal prudence if you have to remain afloat.The family atmosphere will be harmonious during the second half of the year. Projects will take off during May and October due to the influence of Jupiter. You have to be realistic in your expectations. Health can be maintained by exercise and recreation.</p>";
        else
            echo "<p> You're Capricorn!</p><p> The year 2022 will be both promising as well as messy for Capricorn individuals. You have to double your efforts to succeed in the job as well as monetary situations. Hard work and tension will impact your health, and you will also vitiate the family atmosphere.Children will have a tough time during the year. If they are of marriageable age, they will tie the knot. The year is favorable for students to pursue higher education. Do not be deterred by tough situations, and always think of alternatives.</p>";    
    }  
}
 
           
  ?>
<br><br>

</center>
</div>
    </form>
 </fieldset>  
</body>
</html>