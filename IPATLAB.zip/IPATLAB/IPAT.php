<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<table border=1 cellpadding=5 cellspacing=5 width=40% height=70%>
	<tr>
		<td colspan=7><h1> <center>JASRONE LAO, NORIEL MILLARES, JOHN ALLEN FELICIDARIO, 
		MARK JHOLAN JAMIN</center></h1></td>

		
	<tr>
		<td>
			<a href='IPAT.php? image=images/1.png&description=PROGRAMMING LANGUAGE'>
				<img src=images/1.png width=50 height=50><b>Programming Language</a>
		</td>
		<td>
			<a href='IPAT.php?image=images/OUTPUT.png&description=PROGRAMMING LANGUAGE'>
				<img src=images/OUTPUT.png width=50 height=50></a>
		</td>
		<td>
			<a href='index.php?image=image2/7.png&description=Wrandell'>
				<img src=image2/7.png width=50 height=50></a>
		</td>
		<td>
			<a href='index.php?image=image2/8.png&description=Wrandell'>
				<img src=image2/8.png width=50 height=50></a>
		</td>
		<td>
			<a href='index.php?image=image2/9.png&description=Wrandell'>
				<img src=image2/9.png width=50 height=50></a>
		</td>
		<td>
			<a href='index.php?image=image2/10.png&description=Wrandell'>
				<img src=image2/10.png width=50 height=50></a>
		</td>
		<td>
			<a href='index.php?image=image3/11.png&description=Wrandell'>
				<img src=image3/11.png width=50 height=50></a>
		</td>

</tr>

<tr>
		<td>
			<a href='index.php?image=image1/2.png&description=robot ako1'>
				<img src=image1/2.png width=50 height=50></a>
		</td>
		<td rowspan=3 colspan=5>
			<?php
				if (isset($_GET['image']))
				{
					$a=$_GET['image'];
					$b=$_GET['description'];
					print "<img src=$a width=200 height=200><br>$b";
				}
			?>
		</td>

		<td>
			<a href='index.php?image=image3/12.png&description=robot ako1'>
				<img src=image3/12.png width=50 height=50></a>
		</td>

</tr>



<tr>
		<td>
			<a href='index.php?image=image1/3.png&description=robot ako'>
				<img src=image1/3.png width=50 height=50></a>
		</td>
		<td>
			<a href='index.php?image=image3/13.png&description=robot ako'>
				<img src=image3/13.png width=50 height=50></a>
		</td>	
</tr>

<tr>
		<td>
			<a href='index.php?image=image1/4.png&description=robot ako'>
				<img src=image1/4.png width=50 height=50></a>
		</td>
		<td>
			<a href='index.php?image=image3/14.png&description=robot ako'>
				<img src=image3/14.png width=50 height=50></a>
		</td>
</tr>

<tr>
	<td>
		<a href='index.php?image=image1/5.png&description=robot ako'>
			<img src=image1/5.png width=50 height=50></a>
	</td>	
	<td>
		<a href='index.php?image=image4/16.png&description=robot ako'>
			<img src=image4/16.png width=50 height=50></a>
	</td>
	<td>
		<a href='index.php?image=image4/17.png&description=robot ako'>
			<img src=image4/17.png width=50 height=50></a>	
	</td>
	<td>
		<a href='index.php?image=image4/18.png&description=robot ako'>
			<img src=image4/18.png width=50 height=50></a>
	</td>
	<td>
		<a href='index.php?image=image4/19.png&description=robot ako'>
			<img src=image4/19.png width=50 height=50></a>
	</td>
	<td>
		<a href='index.php?image=image4/20.png&description=robot ako'>
			<img src=image4/20.png width=50 height=50></a>
	</td>
	<td>
		<a href='index.php?image=image3/15.png&description=robot ako'>
			<img src=image3/15.png width=50 height=50></a>
	</td>
</tr>

</tr>

</body>
</html>